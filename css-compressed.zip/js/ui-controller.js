/**
 * UIController
 * Connects the UI elements, user interactions, animation loop,
 * algorithm execution, and dashboards.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Core Modules
  const model = new NetworkModel();
  const graphContainer = document.getElementById('network-canvas');
  const visualizer = new GraphVisualizer(graphContainer, model);
  const solver = new EdmondsKarpSolver(model);
  const waterAnim = new WaterAnimations();

  // Execution & Step State
  let algorithmResults = null;
  let currentStepIndex = 0;
  let isPlaying = false;
  let playInterval = null;
  let animationSpeed = 1000; // ms per step
  let stepFilterMode = 'all'; // 'all' or 'pathsOnly'
  let filteredStepIndices = [];

  // DOM Elements
  const btnStartViz = document.getElementById('btn-start-viz');
  const btnStartSimulation = document.getElementById('btn-start-simulation');
  const btnLoadSample = document.getElementById('btn-load-sample');
  const btnLoadSampleHero = document.getElementById('btn-load-sample-hero');
  const presetSelector = document.getElementById('preset-selector');

  const btnRunAlgorithm = document.getElementById('btn-run-algo');
  const btnPlayPause = document.getElementById('btn-play-pause');
  const btnNextStep = document.getElementById('btn-next-step');
  const btnPrevStep = document.getElementById('btn-prev-step');
  const btnResetSteps = document.getElementById('btn-reset-steps');
  const speedSlider = document.getElementById('speed-slider');
  const speedLabel = document.getElementById('speed-label');
  const stepFilterToggle = document.getElementById('step-filter-toggle');

  const btnTogglePhysics = document.getElementById('btn-toggle-physics');
  const btnFitGraph = document.getElementById('btn-fit-graph');
  const viewModeRadios = document.querySelectorAll('input[name="view-mode"]');

  const selectSource = document.getElementById('select-source-node');
  const selectSink = document.getElementById('select-sink-node');
  const btnApplyTerminals = document.getElementById('btn-apply-terminals');

  // Inspector Elements
  const stepBadge = document.getElementById('step-badge');
  const stepCounterText = document.getElementById('step-counter-text');
  const stepProgressBar = document.getElementById('step-progress-bar');
  const stepTitle = document.getElementById('step-title');
  const stepDesc = document.getElementById('step-description');
  const stepPathContainer = document.getElementById('step-path-container');
  const stepBottleneckVal = document.getElementById('step-bottleneck-val');
  const stepFlowVal = document.getElementById('step-flow-val');
  const stepQueueContainer = document.getElementById('step-queue-container');
  const stepVisitedContainer = document.getElementById('step-visited-container');

  // Modals & Forms
  const modalAddNode = document.getElementById('modal-add-node');
  const modalAddPipe = document.getElementById('modal-add-pipe');
  const modalEditPipe = document.getElementById('modal-edit-pipe');
  const btnOpenAddNode = document.getElementById('btn-open-add-node');
  const btnOpenAddPipe = document.getElementById('btn-open-add-pipe');
  const btnResetNetwork = document.getElementById('btn-reset-network');

  // Forms
  const formAddNode = document.getElementById('form-add-node');
  const formAddPipe = document.getElementById('form-add-pipe');
  const formEditPipe = document.getElementById('form-edit-pipe');
  const btnDeletePipe = document.getElementById('btn-delete-pipe');

  // Results Dashboard Elements
  const resMaxFlow = document.getElementById('res-max-flow');
  const resPathsCount = document.getElementById('res-paths-count');
  const resMinCutCap = document.getElementById('res-mincut-cap');
  const resBottlenecksCount = document.getElementById('res-bottlenecks-count');
  const tableAugmentations = document.getElementById('table-augmentations-body');
  const tablePipeUtilization = document.getElementById('table-utilization-body');
  const minCutSourceSet = document.getElementById('mincut-source-set');
  const minCutSinkSet = document.getElementById('mincut-sink-set');
  const minCutEdgesList = document.getElementById('mincut-edges-list');
  const explanationSummaryText = document.getElementById('explanation-summary-text');

  // Toasts
  const toastContainer = document.getElementById('toast-container');
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type} animate-slide-in`;
    const icon = type === 'success' ? '✓' : (type === 'error' ? '✕' : 'ℹ');
    toast.innerHTML = `<span class="toast-icon">${icon}</span> <span class="toast-msg">${message}</span>`;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('toast-fade-out');
      setTimeout(() => toast.remove(), 400);
    }, 3500);
  }

  // Populate Source/Sink Select Dropdowns
  function updateTerminalDropdowns() {
    const nodes = Array.from(model.nodes.keys()).sort();
    const currentSrc = model.sourceId || 'S';
    const currentSink = model.sinkId || 'T';

    selectSource.innerHTML = '';
    selectSink.innerHTML = '';

    nodes.forEach(nId => {
      const optS = document.createElement('option');
      optS.value = nId;
      optS.textContent = `${nId} (${model.nodes.get(nId).label || nId})`;
      if (nId === currentSrc) optS.selected = true;
      selectSource.appendChild(optS);

      const optT = document.createElement('option');
      optT.value = nId;
      optT.textContent = `${nId} (${model.nodes.get(nId).label || nId})`;
      if (nId === currentSink) optT.selected = true;
      selectSink.appendChild(optT);
    });

    // Populate pipe form dropdowns
    const pipeFrom = document.getElementById('pipe-from');
    const pipeTo = document.getElementById('pipe-to');
    if (pipeFrom && pipeTo) {
      pipeFrom.innerHTML = '';
      pipeTo.innerHTML = '';
      nodes.forEach(nId => {
        const o1 = document.createElement('option');
        o1.value = nId;
        o1.textContent = nId;
        pipeFrom.appendChild(o1);

        const o2 = document.createElement('option');
        o2.value = nId;
        o2.textContent = nId;
        pipeTo.appendChild(o2);
      });
      if (nodes.length > 1) {
        pipeTo.selectedIndex = 1;
      }
    }
  }

  // Subscribe model changes to visualizer & dropdowns
  model.subscribe((event, data) => {
    updateTerminalDropdowns();
    visualizer.render();
    resetAlgorithmState();
  });

  // Load default network initially
  model.loadDefaultSample();
  updateTerminalDropdowns();
  visualizer.fit();

  // Scroll to visualization workbench and initialize graph
  function handleStartSimulation(e) {
    if (e && e.preventDefault) {
      e.preventDefault();
    }

    // 1. Ensure default sample network is loaded if model is uninitialized or empty
    if (!model.nodes || model.nodes.size === 0 || !model.edges || model.edges.size === 0) {
      model.loadDefaultSample();
      if (presetSelector) presetSelector.value = 'default';
    }

    // 2. Reset algorithm state to clean initial ready state
    resetAlgorithmState();

    // 3. Close mobile navigation menu if open
    if (navMenu && navMenu.classList.contains('active')) {
      navMenu.classList.remove('active');
    }

    // 4. Scroll smoothly to Network Workbench section
    const vizSection = document.getElementById('visualization-section');
    if (vizSection) {
      vizSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // 5. Ensure the Vis Network graph is completely rendered, positioned, and fitted
    visualizer.render();
    setTimeout(() => {
      visualizer.render();
      visualizer.fit();
    }, 150);

    showToast('Network Workbench ready. Start stepping or click Run Full!', 'info');
  }

  // Connect Start Simulation buttons
  if (btnStartSimulation) {
    btnStartSimulation.addEventListener('click', handleStartSimulation);
  }

  if (btnStartViz) {
    btnStartViz.addEventListener('click', handleStartSimulation);
  }

  // Also catch any anchor link with href="#visualization-section"
  document.querySelectorAll('a[href="#visualization-section"]').forEach(link => {
    link.addEventListener('click', handleStartSimulation);
  });

  if (btnLoadSampleHero) {
    btnLoadSampleHero.addEventListener('click', (e) => {
      if (e) e.preventDefault();
      model.loadDefaultSample();
      if (presetSelector) presetSelector.value = 'default';
      handleStartSimulation();
      showToast('Loaded Default Sample Water Network (Max Flow = 12 L/s)', 'success');
    });
  }

  if (btnLoadSample) {
    btnLoadSample.addEventListener('click', () => {
      model.loadDefaultSample();
      if (presetSelector) presetSelector.value = 'default';
      resetAlgorithmState();
      visualizer.render();
      setTimeout(() => visualizer.fit(), 100);
      showToast('Loaded Default Sample Network', 'success');
    });
  }

  // Presets selector
  if (presetSelector) {
    presetSelector.addEventListener('change', (e) => {
      const val = e.target.value;
      if (val === 'default') {
        model.loadDefaultSample();
        showToast('Loaded Default Sample Network (S→A:10, S→B:8, ...)', 'info');
      } else if (val === 'cancellation') {
        model.loadCancellationDemo();
        showToast('Loaded Reverse Edge / Flow Cancellation Demo', 'info');
      } else if (val === 'complex') {
        model.loadComplexGrid();
        showToast('Loaded Metropolitan Water Grid', 'info');
      }
      visualizer.fit();
    });
  }

  // Terminal node update
  if (btnApplyTerminals) {
    btnApplyTerminals.addEventListener('click', () => {
      try {
        model.setTerminals(selectSource.value, selectSink.value);
        showToast(`Source set to "${selectSource.value}", Destination set to "${selectSink.value}"`, 'success');
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  // View Mode: Physical vs Residual
  viewModeRadios.forEach(radio => {
    radio.addEventListener('change', (e) => {
      visualizer.setViewMode(e.target.value);
      if (algorithmResults && algorithmResults.steps[currentStepIndex]) {
        visualizer.render(algorithmResults.steps[currentStepIndex]);
      }
    });
  });

  // Toggle Physics
  let physicsOn = false;
  if (btnTogglePhysics) {
    btnTogglePhysics.addEventListener('click', () => {
      physicsOn = !physicsOn;
      visualizer.togglePhysics(physicsOn);
      btnTogglePhysics.classList.toggle('active', physicsOn);
      btnTogglePhysics.innerHTML = physicsOn
        ? `<span class="icon">🔓</span> Physics On`
        : `<span class="icon">🔒</span> Freeze Layout`;
      showToast(physicsOn ? 'Physics enabled (drag nodes to reshape)' : 'Layout positions locked', 'info');
    });
  }

  // Fit Graph
  if (btnFitGraph) {
    btnFitGraph.addEventListener('click', () => {
      visualizer.fit();
    });
  }

  // Interactive Click on Node / Edge from Canvas
  visualizer.onSelect((info) => {
    if (info.type === 'edge') {
      const edge = model.edges.get(info.id);
      if (edge) {
        document.getElementById('edit-edge-id').value = edge.id;
        document.getElementById('edit-edge-title').textContent = `Pipe: ${edge.from} → ${edge.to}`;
        document.getElementById('edit-edge-capacity').value = edge.capacity;
        modalEditPipe.classList.add('active');
      }
    } else if (info.type === 'node') {
      showToast(`Selected Node "${info.id}" (${model.nodes.get(info.id).label})`, 'info');
    }
  });

  // Modal open & close handlers
  document.querySelectorAll('.modal-close, .modal-backdrop').forEach(el => {
    el.addEventListener('click', () => {
      document.querySelectorAll('.modal').forEach(m => m.classList.remove('active'));
    });
  });

  if (btnOpenAddNode) {
    btnOpenAddNode.addEventListener('click', () => {
      modalAddNode.classList.add('active');
    });
  }

  if (btnOpenAddPipe) {
    btnOpenAddPipe.addEventListener('click', () => {
      updateTerminalDropdowns();
      modalAddPipe.classList.add('active');
    });
  }

  // Add Node Form
  if (formAddNode) {
    formAddNode.addEventListener('submit', (e) => {
      e.preventDefault();
      const id = document.getElementById('node-id').value.trim();
      const label = document.getElementById('node-label').value.trim();
      const role = document.getElementById('node-role').value;
      try {
        model.addNode(id, label || id, role);
        modalAddNode.classList.remove('active');
        formAddNode.reset();
        showToast(`Node "${id}" added successfully.`, 'success');
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  // Add Pipe Form
  if (formAddPipe) {
    formAddPipe.addEventListener('submit', (e) => {
      e.preventDefault();
      const from = document.getElementById('pipe-from').value;
      const to = document.getElementById('pipe-to').value;
      const cap = parseFloat(document.getElementById('pipe-capacity').value);
      try {
        model.addEdge(from, to, cap);
        modalAddPipe.classList.remove('active');
        formAddPipe.reset();
        showToast(`Pipe "${from} → ${to}" with capacity ${cap} L/s added.`, 'success');
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  // Edit Pipe Form
  if (formEditPipe) {
    formEditPipe.addEventListener('submit', (e) => {
      e.preventDefault();
      const edgeId = document.getElementById('edit-edge-id').value;
      const newCap = parseFloat(document.getElementById('edit-edge-capacity').value);
      try {
        model.updateEdgeCapacity(edgeId, newCap);
        modalEditPipe.classList.remove('active');
        showToast(`Updated capacity of pipe "${edgeId}" to ${newCap} L/s.`, 'success');
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  // Delete Pipe
  if (btnDeletePipe) {
    btnDeletePipe.addEventListener('click', () => {
      const edgeId = document.getElementById('edit-edge-id').value;
      if (confirm(`Are you sure you want to remove pipe "${edgeId}"?`)) {
        model.removeEdge(edgeId);
        modalEditPipe.classList.remove('active');
        showToast(`Pipe "${edgeId}" deleted.`, 'info');
      }
    });
  }

  // Reset Network
  if (btnResetNetwork) {
    btnResetNetwork.addEventListener('click', () => {
      if (confirm('Reset entire network to empty state?')) {
        model.clear();
        showToast('Network cleared. Add nodes and pipes to build a network.', 'info');
      }
    });
  }

  // Reset Algorithm & Step State
  function resetAlgorithmState() {
    pauseAnimation();
    algorithmResults = null;
    currentStepIndex = 0;
    filteredStepIndices = [];
    model.resetFlows();

    // Reset UI indicators
    stepBadge.className = 'badge badge-slate';
    stepBadge.textContent = 'Idle / Ready';
    stepCounterText.textContent = 'Step 0 of 0';
    stepProgressBar.style.width = '0%';
    stepTitle.textContent = 'Edmonds–Karp Ready';
    stepDesc.textContent = 'Click "Run Algorithm" or "Play Animation" to begin Edmonds–Karp Maximum Flow computation via Breadth-First Search (BFS).';
    stepPathContainer.innerHTML = '<span class="text-muted">None</span>';
    stepBottleneckVal.textContent = '0 L/s';
    stepFlowVal.textContent = '0 L/s';
    stepQueueContainer.innerHTML = '<span class="text-muted">Empty</span>';
    stepVisitedContainer.innerHTML = '<span class="text-muted">None</span>';

    WaterAnimations.updateTankGauges(0, 12);
  }

  // Step Filter mode toggle (All BFS steps vs Only Augmentations)
  if (stepFilterToggle) {
    stepFilterToggle.addEventListener('change', (e) => {
      stepFilterMode = e.target.checked ? 'pathsOnly' : 'all';
      recalculateFilteredSteps();
      showToast(stepFilterMode === 'pathsOnly' ? 'Showing Augmenting Paths Only' : 'Showing All BFS Steps', 'info');
    });
  }

  function recalculateFilteredSteps() {
    if (!algorithmResults) return;
    if (stepFilterMode === 'pathsOnly') {
      filteredStepIndices = [];
      algorithmResults.steps.forEach((s, idx) => {
        if (s.type === 'INIT' || s.type === 'PATH_FOUND' || s.type === 'FLOW_AUGMENTED' || s.type === 'TERMINATION') {
          filteredStepIndices.push(idx);
        }
      });
    } else {
      filteredStepIndices = algorithmResults.steps.map((_, i) => i);
    }
  }

  // Run Solver & Generate Steps
  function ensureAlgorithmSolved() {
    // If graph is empty or missing pipes, auto-load default sample
    if (!model.nodes || model.nodes.size < 2 || !model.edges || model.edges.size === 0) {
      model.loadDefaultSample();
      if (presetSelector) presetSelector.value = 'default';
      visualizer.render();
      setTimeout(() => visualizer.fit(), 100);
      showToast('Loaded Default Sample Network for simulation.', 'info');
    }

    if (!algorithmResults) {
      try {
        algorithmResults = solver.solve({ detailedBfs: true });
        recalculateFilteredSteps();
        currentStepIndex = 0;
        populateResultsDashboard(algorithmResults);
      } catch (err) {
        showToast(err.message, 'error');
        return false;
      }
    }
    return true;
  }

  // Render a specific step
  function applyStep(stepIdx) {
    if (!algorithmResults || !algorithmResults.steps[stepIdx]) return;
    const step = algorithmResults.steps[stepIdx];
    currentStepIndex = stepIdx;

    // Update Graph Visualizer
    visualizer.render(step);

    // Update Progress
    const totalSteps = algorithmResults.steps.length;
    const currentProg = Math.round(((stepIdx + 1) / totalSteps) * 100);
    stepCounterText.textContent = `Step ${stepIdx + 1} of ${totalSteps}`;
    stepProgressBar.style.width = `${currentProg}%`;

    // Update Badge
    stepBadge.className = 'badge';
    if (step.type === 'INIT') {
      stepBadge.classList.add('badge-slate');
      stepBadge.textContent = 'Initialized';
    } else if (step.type === 'BFS_START' || step.type === 'BFS_EXPLORE') {
      stepBadge.classList.add('badge-blue');
      stepBadge.textContent = 'BFS Traversal';
    } else if (step.type === 'PATH_FOUND') {
      stepBadge.classList.add('badge-cyan');
      stepBadge.textContent = 'Path Found!';
    } else if (step.type === 'FLOW_AUGMENTED') {
      stepBadge.classList.add('badge-green');
      stepBadge.textContent = `Flow +${step.bottleneck} L/s`;
    } else if (step.type === 'TERMINATION') {
      stepBadge.classList.add('badge-purple');
      stepBadge.textContent = 'Max Flow Achieved';
    }

    stepTitle.textContent = step.title;
    stepDesc.textContent = step.description;

    // Active Path Display
    if (step.activePath && step.activePath.length > 0) {
      stepPathContainer.innerHTML = step.activePath.map(n => `<span class="path-node-pill">${n}</span>`).join('<span class="path-arrow">→</span>');
    } else {
      stepPathContainer.innerHTML = '<span class="text-muted">None active</span>';
    }

    // Bottleneck and Flow
    stepBottleneckVal.textContent = step.bottleneck ? `${step.bottleneck} L/s` : '—';
    stepFlowVal.textContent = `${step.totalFlow} L/s`;

    // Queue & Visited
    if (step.queue && step.queue.length > 0) {
      stepQueueContainer.innerHTML = step.queue.map(q => `<span class="queue-item">${q}</span>`).join('');
    } else {
      stepQueueContainer.innerHTML = '<span class="text-muted">Empty</span>';
    }

    if (step.visitedNodes && step.visitedNodes.length > 0) {
      stepVisitedContainer.innerHTML = step.visitedNodes.map(v => `<span class="visited-item">${v}</span>`).join('');
    } else {
      stepVisitedContainer.innerHTML = '<span class="text-muted">None</span>';
    }

    // Water level gauges
    WaterAnimations.updateTankGauges(step.totalFlow, algorithmResults.maxFlow || 12);
  }

  // Animation Controls
  function nextStep() {
    if (!ensureAlgorithmSolved()) return;

    if (stepFilterMode === 'pathsOnly') {
      const currentFilteredPos = filteredStepIndices.findIndex(idx => idx >= currentStepIndex);
      if (currentFilteredPos >= 0 && currentFilteredPos < filteredStepIndices.length - 1) {
        applyStep(filteredStepIndices[currentFilteredPos + 1]);
      } else {
        pauseAnimation();
        showToast('Reached final step of algorithm.', 'info');
      }
    } else {
      if (currentStepIndex < algorithmResults.steps.length - 1) {
        applyStep(currentStepIndex + 1);
      } else {
        pauseAnimation();
        showToast('Reached final step of algorithm.', 'info');
      }
    }
  }

  function prevStep() {
    if (!ensureAlgorithmSolved()) return;

    if (stepFilterMode === 'pathsOnly') {
      const currentFilteredPos = filteredStepIndices.findIndex(idx => idx >= currentStepIndex);
      if (currentFilteredPos > 0) {
        applyStep(filteredStepIndices[currentFilteredPos - 1]);
      }
    } else {
      if (currentStepIndex > 0) {
        applyStep(currentStepIndex - 1);
      }
    }
  }

  function playAnimation() {
    if (!ensureAlgorithmSolved()) return;
    isPlaying = true;
    btnPlayPause.innerHTML = `<span class="icon">⏸</span> Pause`;
    btnPlayPause.classList.add('btn-pause-state');

    if (currentStepIndex >= algorithmResults.steps.length - 1) {
      currentStepIndex = 0;
      applyStep(0);
    }

    clearInterval(playInterval);
    playInterval = setInterval(() => {
      const maxIdx = algorithmResults.steps.length - 1;
      if (currentStepIndex >= maxIdx) {
        pauseAnimation();
        showToast('Max Flow computation finished!', 'success');
      } else {
        nextStep();
      }
    }, animationSpeed);
  }

  function pauseAnimation() {
    isPlaying = false;
    if (playInterval) {
      clearInterval(playInterval);
      playInterval = null;
    }
    if (btnPlayPause) {
      btnPlayPause.innerHTML = `<span class="icon">▶</span> Play`;
      btnPlayPause.classList.remove('btn-pause-state');
    }
  }

  // Bind Control Buttons
  if (btnRunAlgorithm) {
    btnRunAlgorithm.addEventListener('click', () => {
      pauseAnimation();
      if (!ensureAlgorithmSolved()) return;
      applyStep(algorithmResults.steps.length - 1);
      showToast(`Completed! Maximum Water Flow is ${algorithmResults.maxFlow} L/s (Full details in Results below)`, 'success');
    });
  }

  if (btnPlayPause) {
    btnPlayPause.addEventListener('click', () => {
      if (isPlaying) {
        pauseAnimation();
      } else {
        playAnimation();
      }
    });
  }

  if (btnNextStep) {
    btnNextStep.addEventListener('click', () => {
      pauseAnimation();
      nextStep();
    });
  }

  if (btnPrevStep) {
    btnPrevStep.addEventListener('click', () => {
      pauseAnimation();
      prevStep();
    });
  }

  if (btnResetSteps) {
    btnResetSteps.addEventListener('click', () => {
      resetAlgorithmState();
      showToast('Algorithm reset to initial step.', 'info');
    });
  }

  // Speed Slider
  if (speedSlider) {
    speedSlider.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value);
      animationSpeed = Math.round(1500 / val);
      speedLabel.textContent = `${val.toFixed(1)}x`;
      if (isPlaying) {
        // Restart interval with new speed
        clearInterval(playInterval);
        playInterval = setInterval(nextStep, animationSpeed);
      }
    });
  }

  // Results Dashboard Population
  function populateResultsDashboard(results) {
    if (!results) return;

    // Hero metrics
    WaterAnimations.animateNumber(resMaxFlow, 0, results.maxFlow, 600, ' L/s');
    resPathsCount.textContent = `${results.augmentingPaths.length} Paths`;
    resMinCutCap.textContent = `${results.minCut.capacity} L/s`;

    const saturatedCount = results.edgeUtilization.filter(e => e.status === 'Saturated').length;
    resBottlenecksCount.textContent = `${saturatedCount} Pipes`;

    // Augmenting Paths Table
    tableAugmentations.innerHTML = '';
    results.augmentingPaths.forEach(p => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td class="font-bold text-center">#${p.iteration}</td>
        <td><span class="path-pill-highlight">${p.pathString}</span></td>
        <td class="text-center font-bold text-blue">${p.bottleneck} L/s</td>
        <td class="text-center font-bold text-green">${p.cumulativeFlow} L/s</td>
        <td class="text-muted text-sm">${p.edgeBreakdown}</td>
      `;
      tableAugmentations.appendChild(row);
    });

    // Pipe Utilization Table
    tablePipeUtilization.innerHTML = '';
    results.edgeUtilization.forEach(e => {
      const row = document.createElement('tr');
      const badgeClass = e.status === 'Saturated' ? 'badge-amber' : (e.status === 'Active' ? 'badge-blue' : 'badge-slate');
      row.innerHTML = `
        <td class="font-bold">${e.from} → ${e.to}</td>
        <td class="text-center">${e.capacity} L/s</td>
        <td class="text-center font-bold">${e.flow} L/s</td>
        <td>
          <div class="utilization-bar-container">
            <div class="utilization-bar-fill ${e.status === 'Saturated' ? 'bg-amber' : 'bg-blue'}" style="width: ${e.utilPercent}%"></div>
            <span class="utilization-text">${e.utilPercent}%</span>
          </div>
        </td>
        <td class="text-center"><span class="badge ${badgeClass}">${e.status}</span></td>
      `;
      tablePipeUtilization.appendChild(row);
    });

    // Min-Cut Details
    minCutSourceSet.textContent = `{ ${results.minCut.sourceSet.join(', ')} }`;
    minCutSinkSet.textContent = `{ ${results.minCut.sinkSet.join(', ')} }`;

    minCutEdgesList.innerHTML = results.cutEdges.map(e =>
      `<span class="mincut-edge-tag"><b>${e.from} → ${e.to}</b> (Cap: ${e.capacity} L/s)</span>`
    ).join(' ');

    // English Explanation Summary
    explanationSummaryText.innerHTML = `
      The algorithm successfully pushed a total of <b>${results.maxFlow} litres per second (L/s)</b> from Reservoir <b>${model.sourceId}</b> to City <b>${model.sinkId}</b> across <b>${results.augmentingPaths.length} BFS augmenting paths</b>.
      <br><br>
      Notice that the destination city is now completely cut off from the source in the residual network because all crossing pipes (specifically <b>${results.cutEdges.map(e => `${e.from} → ${e.to}`).join(' and ')}</b>) are 100% saturated with a combined capacity of <b>${results.minCut.capacity} L/s</b>.
      This verifies the fundamental <b>Max-Flow Min-Cut Theorem</b>: the maximum flow achieved (${results.maxFlow} L/s) exactly equals the minimum bottleneck cut capacity (${results.minCut.capacity} L/s).
    `;
  }

  // Print / Save Report
  const btnPrintReport = document.getElementById('btn-print-report');
  if (btnPrintReport) {
    btnPrintReport.addEventListener('click', () => {
      window.print();
    });
  }

  // Responsive mobile menu toggle
  const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
  const navMenu = document.getElementById('nav-menu');
  if (mobileMenuToggle && navMenu) {
    mobileMenuToggle.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });
  }
});
