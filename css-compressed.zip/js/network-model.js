/**
 * NetworkModel
 * Manages the flow network graph state: nodes, directed pipes, capacities, and flows.
 * Provides validation, preset loading, and state serialization.
 */

class NetworkModel {
  constructor() {
    this.nodes = new Map(); // id -> { id, label, role, x, y }
    this.edges = new Map(); // id -> { id, from, to, capacity, flow }
    this.sourceId = 'S';
    this.sinkId = 'T';
    this.listeners = [];
  }

  subscribe(listener) {
    this.listeners.push(listener);
  }

  notify(event, data) {
    this.listeners.forEach(fn => fn(event, data));
  }

  // Clear all data
  clear() {
    this.nodes.clear();
    this.edges.clear();
    this.sourceId = null;
    this.sinkId = null;
    this.notify('change', { type: 'clear' });
  }

  // Reset flows to 0 while keeping structure and capacities
  resetFlows() {
    for (const edge of this.edges.values()) {
      edge.flow = 0;
    }
    this.notify('change', { type: 'resetFlows' });
  }

  // Add a node
  addNode(id, label = null, role = 'junction', x = null, y = null) {
    if (!id || typeof id !== 'string') {
      throw new Error('Node ID must be a valid non-empty string.');
    }
    const cleanId = id.trim().toUpperCase();
    if (this.nodes.has(cleanId)) {
      throw new Error(`Node "${cleanId}" already exists.`);
    }

    const nodeData = {
      id: cleanId,
      label: label ? label.trim() : cleanId,
      role: role || 'junction', // 'reservoir' (S), 'city' (T), 'tank', 'junction'
      x: x !== null ? x : undefined,
      y: y !== null ? y : undefined
    };

    this.nodes.set(cleanId, nodeData);
    this.notify('change', { type: 'addNode', node: nodeData });
    return nodeData;
  }

  // Remove a node and connected edges
  removeNode(id) {
    const cleanId = id.trim().toUpperCase();
    if (!this.nodes.has(cleanId)) {
      throw new Error(`Node "${cleanId}" does not exist.`);
    }

    if (cleanId === this.sourceId) this.sourceId = null;
    if (cleanId === this.sinkId) this.sinkId = null;

    // Delete connected edges
    const edgesToDelete = [];
    for (const [edgeId, edge] of this.edges.entries()) {
      if (edge.from === cleanId || edge.to === cleanId) {
        edgesToDelete.push(edgeId);
      }
    }
    edgesToDelete.forEach(edgeId => this.edges.delete(edgeId));

    this.nodes.delete(cleanId);
    this.notify('change', { type: 'removeNode', id: cleanId });
  }

  // Add directed edge
  addEdge(from, to, capacity, id = null) {
    const fromId = from.trim().toUpperCase();
    const toId = to.trim().toUpperCase();

    if (!this.nodes.has(fromId)) {
      throw new Error(`Source node "${fromId}" does not exist.`);
    }
    if (!this.nodes.has(toId)) {
      throw new Error(`Destination node "${toId}" does not exist.`);
    }
    if (fromId === toId) {
      throw new Error('Self-loop pipes are not allowed in water flow networks.');
    }

    const capNum = parseFloat(capacity);
    if (isNaN(capNum) || capNum <= 0) {
      throw new Error('Pipe capacity must be a positive number greater than 0.');
    }

    const edgeKey = id || `${fromId}_to_${toId}`;
    if (this.edges.has(edgeKey)) {
      throw new Error(`Pipe from "${fromId}" to "${toId}" already exists. Edit its capacity instead.`);
    }

    const edgeData = {
      id: edgeKey,
      from: fromId,
      to: toId,
      capacity: capNum,
      flow: 0
    };

    this.edges.set(edgeKey, edgeData);
    this.notify('change', { type: 'addEdge', edge: edgeData });
    return edgeData;
  }

  // Update existing edge capacity
  updateEdgeCapacity(edgeId, newCapacity) {
    if (!this.edges.has(edgeId)) {
      throw new Error(`Pipe with ID "${edgeId}" not found.`);
    }
    const capNum = parseFloat(newCapacity);
    if (isNaN(capNum) || capNum <= 0) {
      throw new Error('Pipe capacity must be a positive number.');
    }

    const edge = this.edges.get(edgeId);
    edge.capacity = capNum;
    if (edge.flow > edge.capacity) {
      edge.flow = edge.capacity;
    }
    this.notify('change', { type: 'updateEdge', edge });
  }

  // Remove edge
  removeEdge(edgeId) {
    if (!this.edges.has(edgeId)) {
      throw new Error(`Pipe with ID "${edgeId}" not found.`);
    }
    this.edges.delete(edgeId);
    this.notify('change', { type: 'removeEdge', id: edgeId });
  }

  // Set Source and Sink
  setTerminals(sourceId, sinkId) {
    const s = sourceId ? sourceId.trim().toUpperCase() : null;
    const t = sinkId ? sinkId.trim().toUpperCase() : null;

    if (!s || !this.nodes.has(s)) {
      throw new Error(`Source node "${s}" is invalid.`);
    }
    if (!t || !this.nodes.has(t)) {
      throw new Error(`Destination city node "${t}" is invalid.`);
    }
    if (s === t) {
      throw new Error('Source (Reservoir) and Destination (City) must be distinct nodes.');
    }

    this.sourceId = s;
    this.sinkId = t;

    // Update roles
    for (const [nodeId, node] of this.nodes.entries()) {
      if (nodeId === s) node.role = 'reservoir';
      else if (nodeId === t) node.role = 'city';
      else if (node.role === 'reservoir' || node.role === 'city') node.role = 'junction';
    }

    this.notify('change', { type: 'terminals', sourceId: s, sinkId: t });
  }

  // Validation before running algorithm
  validate() {
    if (this.nodes.size < 2) {
      return { valid: false, message: 'Network must contain at least 2 nodes.' };
    }
    if (!this.sourceId || !this.nodes.has(this.sourceId)) {
      return { valid: false, message: 'Please designate a valid Source Reservoir (S).' };
    }
    if (!this.sinkId || !this.nodes.has(this.sinkId)) {
      return { valid: false, message: 'Please designate a valid Destination City (T).' };
    }
    if (this.sourceId === this.sinkId) {
      return { valid: false, message: 'Source and Destination City cannot be the same node.' };
    }
    if (this.edges.size === 0) {
      return { valid: false, message: 'Please add at least one pipe connection between nodes.' };
    }
    return { valid: true };
  }

  // Load the default project sample network
  loadDefaultSample() {
    this.clear();

    // S, A, B, C, D, T with designated layout coordinates for beautiful presentation
    this.addNode('S', 'S (Main Reservoir)', 'reservoir', -300, 0);
    this.addNode('A', 'A (Pump Station A)', 'tank', -120, -140);
    this.addNode('B', 'B (Pump Station B)', 'tank', -120, 140);
    this.addNode('C', 'C (Junction C)', 'junction', 120, -140);
    this.addNode('D', 'D (Booster Station D)', 'junction', 120, 140);
    this.addNode('T', 'T (Destination City)', 'city', 300, 0);

    // Default edges specified in assignment:
    // S → A: 10
    // S → B: 8
    // A → B: 2
    // A → C: 5
    // B → C: 10
    // B → D: 5
    // C → T: 7
    // D → T: 8
    this.addEdge('S', 'A', 10);
    this.addEdge('S', 'B', 8);
    this.addEdge('A', 'B', 2);
    this.addEdge('A', 'C', 5);
    this.addEdge('B', 'C', 10);
    this.addEdge('B', 'D', 5);
    this.addEdge('C', 'T', 7);
    this.addEdge('D', 'T', 8);

    this.setTerminals('S', 'T');
    this.notify('loadPreset', { name: 'Default Sample Network' });
  }

  // Load an illustrative network highlighting Reverse Residual Edges (flow cancellation)
  loadCancellationDemo() {
    this.clear();
    this.addNode('S', 'S (Main Reservoir)', 'reservoir', -250, 0);
    this.addNode('A', 'A (North Tank)', 'tank', -80, -120);
    this.addNode('B', 'B (South Tank)', 'tank', -80, 120);
    this.addNode('T', 'T (Destination City)', 'city', 250, 0);

    // Classic 4-node flow cancellation example:
    // S -> A: 10, S -> B: 10
    // A -> B: 1 (cross pipe that tests reverse flow correction)
    // A -> T: 10, B -> T: 10
    this.addEdge('S', 'A', 10);
    this.addEdge('S', 'B', 10);
    this.addEdge('A', 'B', 1);
    this.addEdge('A', 'T', 10);
    this.addEdge('B', 'T', 10);

    this.setTerminals('S', 'T');
    this.notify('loadPreset', { name: 'Flow Cancellation Demo' });
  }

  // Load a larger multi-stage city grid
  loadComplexGrid() {
    this.clear();
    this.addNode('S', 'S (Central Reservoir)', 'reservoir', -350, 0);
    this.addNode('A', 'Tank 1', 'tank', -180, -160);
    this.addNode('B', 'Tank 2', 'tank', -180, 0);
    this.addNode('C', 'Tank 3', 'tank', -180, 160);
    this.addNode('D', 'Junction 1', 'junction', 80, -160);
    this.addNode('E', 'Junction 2', 'junction', 80, 0);
    this.addNode('F', 'Junction 3', 'junction', 80, 160);
    this.addNode('T', 'T (Metropolitan City)', 'city', 350, 0);

    this.addEdge('S', 'A', 12);
    this.addEdge('S', 'B', 15);
    this.addEdge('S', 'C', 10);
    this.addEdge('A', 'D', 9);
    this.addEdge('A', 'E', 4);
    this.addEdge('B', 'D', 6);
    this.addEdge('B', 'E', 8);
    this.addEdge('B', 'F', 5);
    this.addEdge('C', 'E', 3);
    this.addEdge('C', 'F', 8);
    this.addEdge('D', 'T', 14);
    this.addEdge('E', 'T', 12);
    this.addEdge('F', 'T', 10);

    this.setTerminals('S', 'T');
    this.notify('loadPreset', { name: 'Metropolitan Grid Network' });
  }

  // Export current state as JSON
  toJSON() {
    return {
      nodes: Array.from(this.nodes.values()),
      edges: Array.from(this.edges.values()),
      sourceId: this.sourceId,
      sinkId: this.sinkId
    };
  }

  // Import state from JSON
  fromJSON(data) {
    this.clear();
    if (data.nodes) {
      data.nodes.forEach(n => this.addNode(n.id, n.label, n.role, n.x, n.y));
    }
    if (data.edges) {
      data.edges.forEach(e => this.addEdge(e.from, e.to, e.capacity, e.id));
    }
    if (data.sourceId && data.sinkId) {
      this.setTerminals(data.sourceId, data.sinkId);
    }
  }
}

// Expose globally or for modules
if (typeof window !== 'undefined') {
  window.NetworkModel = NetworkModel;
}
