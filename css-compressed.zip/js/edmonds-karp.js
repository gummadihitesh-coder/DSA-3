/**
 * EdmondsKarpSolver
 * Implements the Edmonds-Karp Maximum Flow Algorithm using Breadth-First Search (BFS).
 * Produces structured trace steps for interactive step-by-step educational visualization.
 */

class EdmondsKarpSolver {
  constructor(networkModel) {
    this.model = networkModel;
  }

  /**
   * Run the full algorithm and generate visual execution steps.
   * @param {Object} options
   *   - detailedBfs: boolean (whether to record every node expansion in BFS or only full path augmentations)
   * @returns {Object} { maxFlow, steps, paths, minCut, cutEdges, stats }
   */
  solve(options = { detailedBfs: true }) {
    const validation = this.model.validate();
    if (!validation.valid) {
      throw new Error(validation.message);
    }

    const source = this.model.sourceId;
    const sink = this.model.sinkId;
    const nodes = Array.from(this.model.nodes.keys());
    const originalEdges = Array.from(this.model.edges.values());

    // Map: u -> Map(v -> capacity)
    const capacity = new Map();
    // Map: u -> Map(v -> flow)
    const flow = new Map();
    // Adjacency list for residual graph: u -> Set(v)
    const adj = new Map();

    nodes.forEach(u => {
      capacity.set(u, new Map());
      flow.set(u, new Map());
      adj.set(u, new Set());
    });

    originalEdges.forEach(e => {
      const u = e.from;
      const v = e.to;
      const cap = e.capacity;

      // In case multiple edges exist between same pair, sum capacities
      const existingCap = capacity.get(u).get(v) || 0;
      capacity.get(u).set(v, existingCap + cap);

      if (!capacity.get(v).has(u)) {
        capacity.get(v).set(u, 0); // reverse original capacity
      }
      flow.get(u).set(v, 0);
      flow.get(v).set(u, 0);

      adj.get(u).add(v);
      adj.get(v).add(u);
    });

    let totalMaxFlow = 0;
    const steps = [];
    const augmentingPaths = [];
    let iteration = 0;

    // Helper to capture a deep snapshot of current flows and residual capacities
    const captureState = (extra = {}) => {
      const edgeStates = [];
      originalEdges.forEach(e => {
        const f = flow.get(e.from).get(e.to) || 0;
        const c = capacity.get(e.from).get(e.to) || 0;
        const resForward = c - f;
        const resReverse = f; // flow pushed forward can be cancelled backward
        edgeStates.push({
          id: e.id,
          from: e.from,
          to: e.to,
          capacity: c,
          flow: f,
          residualForward: resForward,
          residualReverse: resReverse,
          isSaturated: f >= c && c > 0
        });
      });

      return {
        iteration,
        totalFlow: totalMaxFlow,
        edges: edgeStates,
        ...extra
      };
    };

    // Step 0: Initial State
    steps.push(captureState({
      type: 'INIT',
      title: 'Algorithm Initialized',
      description: `Initialized water network with ${nodes.length} reservoirs/junctions and ${originalEdges.length} pipes. All pipe flows set to 0. Source is "${source}", Destination is "${sink}".`,
      activePath: [],
      visitedNodes: [],
      queue: [source],
      bottleneck: 0
    }));

    // Edmonds-Karp Outer Loop
    while (true) {
      iteration++;

      // BFS to find the shortest augmenting path (fewest edges) from source to sink in residual graph
      const parent = new Map(); // child -> { parent, edgeResidual, isReverse }
      const queue = [source];
      const visited = new Set([source]);

      // BFS Exploration steps recording if detailed mode is on
      const bfsDiscoveryLog = [];

      if (options.detailedBfs) {
        steps.push(captureState({
          type: 'BFS_START',
          title: `Iteration #${iteration}: Starting BFS Search`,
          description: `Initiating Breadth-First Search from Source Reservoir "${source}" to find the shortest available water flow path with remaining capacity.`,
          queue: [...queue],
          visitedNodes: Array.from(visited),
          activePath: []
        }));
      }

      let pathFound = false;

      while (queue.length > 0) {
        const curr = queue.shift();

        if (curr === sink) {
          pathFound = true;
          break;
        }

        const neighbors = Array.from(adj.get(curr) || []).sort(); // Sort for deterministic BFS traversal

        for (const next of neighbors) {
          const cap = capacity.get(curr).get(next) || 0;
          const fl = flow.get(curr).get(next) || 0;
          const residual = cap - fl;

          if (residual > 0 && !visited.has(next)) {
            visited.add(next);
            // Check if this residual edge is a forward original pipe or reverse cancellation pipe
            const isOriginal = (capacity.get(curr).get(next) || 0) > 0;
            parent.set(next, {
              node: curr,
              residual,
              isReverse: !isOriginal
            });
            queue.push(next);
            bfsDiscoveryLog.push({ from: curr, to: next, residual });

            if (options.detailedBfs) {
              steps.push(captureState({
                type: 'BFS_EXPLORE',
                title: `Iteration #${iteration}: BFS Explored Pipe ${curr} → ${next}`,
                description: `BFS reached node "${next}" from "${curr}" via residual capacity of ${residual} L/s. Current Queue: [${queue.join(', ')}].`,
                currentNode: curr,
                targetNode: next,
                visitedNodes: Array.from(visited),
                queue: [...queue],
                activePath: []
              }));
            }

            if (next === sink) {
              pathFound = true;
              break;
            }
          }
        }

        if (pathFound) break;
      }

      // If BFS failed to reach Sink T, no more augmenting paths exist!
      if (!pathFound) {
        // Algorithm terminates
        break;
      }

      // Reconstruct the augmenting path from sink back to source
      const pathNodes = [];
      const pathEdges = [];
      let curr = sink;
      let bottleneck = Infinity;

      while (curr !== source) {
        const pInfo = parent.get(curr);
        const pNode = pInfo.node;
        const res = pInfo.residual;
        bottleneck = Math.min(bottleneck, res);

        pathNodes.unshift(curr);
        pathEdges.unshift({
          from: pNode,
          to: curr,
          residual: res,
          isReverse: pInfo.isReverse
        });
        curr = pNode;
      }
      pathNodes.unshift(source);

      // Step: Augmenting Path Found & Bottleneck Calculated
      steps.push(captureState({
        type: 'PATH_FOUND',
        title: `Iteration #${iteration}: Shortest Augmenting Path Found!`,
        description: `BFS found path: ${pathNodes.join(' → ')}. Bottleneck capacity is min(${pathEdges.map(e => e.residual).join(', ')}) = ${bottleneck} L/s.`,
        activePath: pathNodes,
        activePathEdges: pathEdges,
        bottleneck,
        visitedNodes: Array.from(visited),
        queue: []
      }));

      // Augment the flow along this path
      for (const pEdge of pathEdges) {
        const u = pEdge.from;
        const v = pEdge.to;

        const currentUtoVFlow = flow.get(u).get(v) || 0;
        const currentVtoUFlow = flow.get(v).get(u) || 0;

        flow.get(u).set(v, currentUtoVFlow + bottleneck);
        flow.get(v).set(u, currentVtoUFlow - bottleneck);
      }

      totalMaxFlow += bottleneck;

      augmentingPaths.push({
        iteration,
        path: pathNodes,
        pathString: pathNodes.join(' → '),
        bottleneck,
        cumulativeFlow: totalMaxFlow,
        edgeBreakdown: pathEdges.map(e => `${e.from}→${e.to} (res: ${e.residual})`).join(', ')
      });

      // Step: Flow Augmented
      steps.push(captureState({
        type: 'FLOW_AUGMENTED',
        title: `Iteration #${iteration}: Flow Pushed (+${bottleneck} L/s)`,
        description: `Successfully pushed ${bottleneck} L/s of water along ${pathNodes.join(' → ')}. Total network throughput is now ${totalMaxFlow} L/s. Residual capacities updated.`,
        activePath: pathNodes,
        activePathEdges: pathEdges,
        bottleneck,
        visitedNodes: Array.from(visited),
        queue: []
      }));
    }

    // Algorithm complete: Find the Minimum Cut
    // Reachable nodes from source S in the final residual graph
    const minCutReachable = new Set();
    const finalQueue = [source];
    minCutReachable.add(source);

    while (finalQueue.length > 0) {
      const curr = finalQueue.shift();
      const neighbors = adj.get(curr) || [];
      for (const next of neighbors) {
        const cap = capacity.get(curr).get(next) || 0;
        const fl = flow.get(curr).get(next) || 0;
        const residual = cap - fl;
        if (residual > 0 && !minCutReachable.has(next)) {
          minCutReachable.add(next);
          finalQueue.push(next);
        }
      }
    }

    const sourceCutSet = Array.from(minCutReachable).sort();
    const sinkCutSet = nodes.filter(n => !minCutReachable.has(n)).sort();

    // Cut edges are original edges going from sourceCutSet to sinkCutSet
    const cutEdges = [];
    let minCutCapacity = 0;
    originalEdges.forEach(e => {
      if (minCutReachable.has(e.from) && !minCutReachable.has(e.to)) {
        cutEdges.push({
          id: e.id,
          from: e.from,
          to: e.to,
          capacity: e.capacity,
          flow: flow.get(e.from).get(e.to) || 0
        });
        minCutCapacity += e.capacity;
      }
    });

    // Step: Final Termination
    steps.push(captureState({
      type: 'TERMINATION',
      title: 'Algorithm Complete — Maximum Water Flow Achieved!',
      description: `BFS cannot find any more augmenting paths from "${source}" to "${sink}". Destination city is disconnected in the residual graph. Maximum Flow is ${totalMaxFlow} L/s. Min-Cut capacity is ${minCutCapacity} L/s (Max-Flow Min-Cut Theorem verified!).`,
      activePath: [],
      visitedNodes: Array.from(minCutReachable),
      queue: [],
      sourceCutSet,
      sinkCutSet,
      cutEdges,
      bottleneck: 0
    }));

    // Compute edge statistics
    const edgeUtilization = originalEdges.map(e => {
      const f = flow.get(e.from).get(e.to) || 0;
      const c = e.capacity;
      const utilPercent = c > 0 ? Math.round((f / c) * 100) : 0;
      return {
        id: e.id,
        from: e.from,
        to: e.to,
        capacity: c,
        flow: f,
        utilPercent,
        status: f === c ? 'Saturated' : (f > 0 ? 'Active' : 'Unused')
      };
    });

    return {
      maxFlow: totalMaxFlow,
      steps,
      augmentingPaths,
      minCut: {
        sourceSet: sourceCutSet,
        sinkSet: sinkCutSet,
        capacity: minCutCapacity,
        isTheoremVerified: totalMaxFlow === minCutCapacity
      },
      cutEdges,
      edgeUtilization,
      summary: {
        nodeCount: nodes.length,
        edgeCount: originalEdges.length,
        totalIterations: augmentingPaths.length,
        maxFlow: totalMaxFlow,
        unit: 'L/s'
      }
    };
  }
}

if (typeof window !== 'undefined') {
  window.EdmondsKarpSolver = EdmondsKarpSolver;
}
