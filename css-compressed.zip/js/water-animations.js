/**
 * WaterAnimations
 * Enhances the UI with subtle water-inspired visuals:
 * - Ambient canvas water bubbles / ripples in Hero
 * - Dynamic water level gauges for Reservoir and City
 * - Number counter animations for flow rates
 */

class WaterAnimations {
  constructor() {
    this.initHeroBubbles();
  }

  // Ambient water bubble particle canvas in hero background
  initHeroBubbles() {
    const canvas = document.getElementById('water-canvas-bg');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let width = (canvas.width = canvas.parentElement.offsetWidth);
    let height = (canvas.height = canvas.parentElement.offsetHeight);

    const resize = () => {
      if (!canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.offsetWidth;
      height = canvas.height = canvas.parentElement.offsetHeight;
    };
    window.addEventListener('resize', resize);

    const bubbles = [];
    const bubbleCount = Math.floor(width / 35);

    for (let i = 0; i < bubbleCount; i++) {
      bubbles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 6 + 2,
        speed: Math.random() * 0.8 + 0.3,
        opacity: Math.random() * 0.3 + 0.1,
        swing: Math.random() * 2,
        swingSpeed: Math.random() * 0.02 + 0.01
      });
    }

    let angle = 0;
    const animate = () => {
      ctx.clearRect(0, 0, width, height);
      angle += 0.02;

      bubbles.forEach(b => {
        b.y -= b.speed;
        b.x += Math.sin(angle + b.swing) * 0.4;

        if (b.y < -10) {
          b.y = height + 10;
          b.x = Math.random() * width;
        }

        ctx.beginPath();
        ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(14, 165, 233, ${b.opacity})`;
        ctx.fill();
        ctx.strokeStyle = `rgba(2, 132, 199, ${b.opacity * 1.5})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      requestAnimationFrame(animate);
    };

    animate();
  }

  // Smooth number counter animation
  static animateNumber(element, start, end, duration = 800, suffix = '') {
    if (!element) return;
    const startTime = performance.now();

    const update = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const ease = 1 - Math.pow(1 - progress, 3);
      const currentVal = Math.round(start + (end - start) * ease);

      element.textContent = `${currentVal}${suffix}`;

      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        element.textContent = `${end}${suffix}`;
      }
    };

    requestAnimationFrame(update);
  }

  // Update water tank fill graphic
  static updateTankGauges(currentFlow, maxPossibleFlow) {
    const reservoirLevel = document.getElementById('gauge-reservoir-level');
    const cityLevel = document.getElementById('gauge-city-level');
    const flowText = document.getElementById('gauge-flow-rate');

    if (!reservoirLevel || !cityLevel) return;

    const percentage = maxPossibleFlow > 0 ? Math.min(100, Math.round((currentFlow / maxPossibleFlow) * 100)) : 0;

    // Reservoir starts full (100%) and discharges water into the network
    const resHeight = Math.max(20, 100 - (percentage * 0.5));
    reservoirLevel.style.height = `${resHeight}%`;

    // City receives the water flow
    const cityHeight = Math.max(15, percentage);
    cityLevel.style.height = `${cityHeight}%`;

    if (flowText) {
      flowText.textContent = `${currentFlow} L/s`;
    }
  }
}

if (typeof window !== 'undefined') {
  window.WaterAnimations = WaterAnimations;
}
