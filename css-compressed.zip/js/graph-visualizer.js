/**
 * GraphVisualizer
 * Renders the Water Distribution Flow Network using Vis Network.
 * Handles node styling, pipe states, path highlighting, animations, and Residual Graph Mode.
 */

class GraphVisualizer {
  constructor(containerElement, networkModel) {
    this.container = containerElement;
    this.model = networkModel;
    this.network = null;
    this.visNodes = null;
    this.visEdges = null;
    this.viewMode = 'physical'; // 'physical' or 'residual'
    this.physicsEnabled = false; // default off for stable layout, can be toggled
    this.onSelectCallback = null;

    this.initVis();
  }

  initVis() {
    this.visNodes = new vis.DataSet();
    this.visEdges = new vis.DataSet();

    const data = {
      nodes: this.visNodes,
      edges: this.visEdges
    };

    const options = {
      autoResize: true,
      interaction: {
        hover: true,
        tooltipDelay: 150,
        selectConnectedEdges: false,
        navigationButtons: true,
        keyboard: false
      },
      physics: {
        enabled: this.physicsEnabled,
        barnesHut: {
          gravitationalConstant: -2500,
          centralGravity: 0.2,
          springLength: 130,
          springConstant: 0.04,
          damping: 0.09
        }
      },
      nodes: {
        font: {
          face: 'Plus Jakarta Sans, Inter, sans-serif',
          size: 14,
          color: '#0f172a',
          strokeWidth: 3,
          strokeColor: '#ffffff'
        },
        borderWidth: 2,
        shadow: {
          enabled: true,
          color: 'rgba(14, 116, 144, 0.2)',
          size: 8,
          x: 2,
          y: 4
        }
      },
      edges: {
        arrows: {
          to: { enabled: true, scaleFactor: 1.1 }
        },
        font: {
          face: 'Plus Jakarta Sans, Inter, sans-serif',
          size: 12,
          align: 'middle',
          background: 'rgba(255, 255, 255, 0.92)',
          strokeWidth: 2,
          strokeColor: '#e0f2fe'
        },
        smooth: {
          type: 'curvedCW',
          roundness: 0.15
        }
      }
    };

    this.network = new vis.Network(this.container, data, options);

    // Event listeners
    this.network.on('click', params => {
      if (this.onSelectCallback) {
        if (params.nodes.length > 0) {
          this.onSelectCallback({ type: 'node', id: params.nodes[0] });
        } else if (params.edges.length > 0) {
          this.onSelectCallback({ type: 'edge', id: params.edges[0] });
        } else {
          this.onSelectCallback({ type: 'canvas' });
        }
      }
    });

    // Populate initial state
    this.render();
  }

  onSelect(callback) {
    this.onSelectCallback = callback;
  }

  setViewMode(mode) {
    if (mode === 'physical' || mode === 'residual') {
      this.viewMode = mode;
      this.render();
    }
  }

  togglePhysics(enabled) {
    this.physicsEnabled = enabled;
    this.network.setOptions({ physics: { enabled } });
  }

  fit() {
    this.network.fit({
      animation: {
        duration: 500,
        easingFunction: 'easeInOutQuad'
      }
    });
  }

  /**
   * Renders the current graph from the model or a specific step state.
   * @param {Object} stepState Optional step snapshot from EdmondsKarpSolver
   */
  render(stepState = null) {
    const nodesArray = [];
    const edgesArray = [];

    const activePathEdges = new Set();
    const activePathNodes = new Set(stepState ? stepState.activePath || [] : []);
    const visitedNodes = new Set(stepState ? stepState.visitedNodes || [] : []);

    if (stepState && stepState.activePathEdges) {
      stepState.activePathEdges.forEach(e => {
        activePathEdges.add(`${e.from}->${e.to}`);
      });
    }

    // Node Rendering
    for (const [nodeId, nodeData] of this.model.nodes.entries()) {
      const isSource = nodeId === this.model.sourceId;
      const isSink = nodeId === this.model.sinkId;
      const isInActivePath = activePathNodes.has(nodeId);
      const isVisited = visitedNodes.has(nodeId);

      let backgroundColor = '#e0f2fe'; // Light water blue
      let borderColor = '#0284c7';
      let iconCode = '💧';
      let shape = 'dot';
      let size = 26;

      if (isSource) {
        backgroundColor = '#0369a1';
        borderColor = '#082f49';
        iconCode = '🌊 S (Reservoir)';
        shape = 'box';
        size = 32;
      } else if (isSink) {
        backgroundColor = '#059669';
        borderColor = '#064e3b';
        iconCode = '🏙️ T (City)';
        shape = 'box';
        size = 32;
      } else if (nodeData.role === 'tank') {
        backgroundColor = '#38bdf8';
        borderColor = '#0284c7';
        iconCode = '🛢️ Tank ' + nodeId;
        size = 28;
      } else {
        iconCode = '⚲ ' + nodeId;
      }

      if (isInActivePath) {
        borderColor = '#2563eb';
        backgroundColor = '#60a5fa';
      } else if (isVisited && !isSource && !isSink) {
        borderColor = '#0d9488';
        backgroundColor = '#ccfbf1';
      }

      const fontColor = (isSource || isSink || isInActivePath) ? '#ffffff' : '#0f172a';

      nodesArray.push({
        id: nodeId,
        label: isSource ? `S: Reservoir` : (isSink ? `T: City Sink` : `${nodeData.label || nodeId}`),
        x: nodeData.x,
        y: nodeData.y,
        shape: shape,
        size: size,
        color: {
          background: backgroundColor,
          border: borderColor,
          highlight: {
            background: '#38bdf8',
            border: '#0369a1'
          }
        },
        font: {
          color: fontColor,
          bold: isSource || isSink || isInActivePath,
          size: isSource || isSink ? 15 : 13
        },
        borderWidth: (isInActivePath || isSource || isSink) ? 3 : 2,
        title: `<b>${nodeData.label}</b><br>Role: ${nodeData.role}<br>ID: ${nodeId}`
      });
    }

    // Edge Rendering
    // If a stepState is passed, use edge values from stepState, else from model
    const edgeDataMap = new Map();
    if (stepState && stepState.edges) {
      stepState.edges.forEach(e => {
        edgeDataMap.set(e.id, e);
      });
    }

    for (const [edgeId, edge] of this.model.edges.entries()) {
      const state = edgeDataMap.get(edgeId) || {
        flow: edge.flow,
        capacity: edge.capacity,
        residualForward: edge.capacity - edge.flow,
        residualReverse: edge.flow,
        isSaturated: edge.flow >= edge.capacity && edge.capacity > 0
      };

      const isPathEdge = activePathEdges.has(`${edge.from}->${edge.to}`);
      const isReversePathEdge = activePathEdges.has(`${edge.to}->${edge.from}`);

      if (this.viewMode === 'physical') {
        // Physical Water Network View: Show Flow / Capacity L/s
        let edgeColor = '#94a3b8'; // idle grey-blue
        let edgeWidth = 2.5;
        let dashes = false;

        if (state.flow > 0) {
          edgeColor = '#0284c7'; // Active water flow
          edgeWidth = Math.min(8, 3 + (state.flow / state.capacity) * 5);
        }

        if (state.isSaturated) {
          edgeColor = '#f59e0b'; // Saturated (bottleneck) in warm amber/orange
        }

        if (isPathEdge) {
          edgeColor = '#2563eb'; // Bright royal blue for current augmenting path
          edgeWidth = 6;
        }

        const labelText = `${state.flow} / ${state.capacity} L/s`;

        edgesArray.push({
          id: edgeId,
          from: edge.from,
          to: edge.to,
          label: labelText,
          width: edgeWidth,
          color: {
            color: edgeColor,
            highlight: '#0284c7',
            hover: '#0369a1'
          },
          dashes: dashes,
          arrows: {
            to: { enabled: true, scaleFactor: 1.1 }
          },
          font: {
            color: state.isSaturated ? '#b45309' : (state.flow > 0 ? '#0369a1' : '#475569'),
            bold: state.flow > 0,
            background: 'rgba(255, 255, 255, 0.95)'
          },
          title: `<b>Pipe ${edge.from} → ${edge.to}</b><br>Flow: ${state.flow} L/s<br>Capacity: ${state.capacity} L/s<br>Residual Capacity: ${state.residualForward} L/s`
        });
      } else {
        // Residual Graph Mode:
        // Forward edge with capacity c(u,v) - f(u,v)
        const forwardRes = state.residualForward;
        if (forwardRes > 0 || isPathEdge) {
          edgesArray.push({
            id: edgeId + '_fwd',
            from: edge.from,
            to: edge.to,
            label: `Res: ${forwardRes} L/s`,
            width: isPathEdge ? 5 : 2.5,
            color: {
              color: isPathEdge ? '#2563eb' : '#0284c7',
              highlight: '#0284c7'
            },
            font: {
              color: '#0369a1',
              bold: true,
              background: 'rgba(240, 249, 255, 0.95)'
            },
            arrows: { to: { enabled: true, scaleFactor: 1.0 } },
            title: `Forward Residual: ${forwardRes} L/s available`
          });
        }

        // Reverse edge with capacity f(u,v) for flow cancellation
        const reverseRes = state.residualReverse;
        if (reverseRes > 0 || isReversePathEdge) {
          edgesArray.push({
            id: edgeId + '_rev',
            from: edge.to,
            to: edge.from,
            label: `Rev: ${reverseRes} L/s`,
            width: isReversePathEdge ? 5 : 2,
            color: {
              color: isReversePathEdge ? '#dc2626' : '#9333ea', // purple/magenta for reverse residual
              highlight: '#9333ea'
            },
            dashes: [5, 5],
            font: {
              color: '#9333ea',
              bold: true,
              background: 'rgba(250, 245, 255, 0.95)'
            },
            arrows: { to: { enabled: true, scaleFactor: 0.9 } },
            title: `Reverse Residual Edge: ${reverseRes} L/s (Can cancel pushed flow)`
          });
        }
      }
    }

    // Update Vis DataSets efficiently
    this.visNodes.clear();
    this.visEdges.clear();
    this.visNodes.add(nodesArray);
    this.visEdges.add(edgesArray);
  }

  // Highlight specific augmenting path with pulse animation
  highlightPath(pathNodes) {
    if (!pathNodes || pathNodes.length < 2) return;
    this.render(); // re-render with clean state
  }
}

if (typeof window !== 'undefined') {
  window.GraphVisualizer = GraphVisualizer;
}
